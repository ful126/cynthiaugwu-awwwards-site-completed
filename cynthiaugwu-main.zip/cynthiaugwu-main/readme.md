smooth scrolling ✅
    attach loco scroll css ✅
    attach locomotive scroll min js ✅
    some code from loco github for js ✅

gsap
    attach gsap
scrolltrigger